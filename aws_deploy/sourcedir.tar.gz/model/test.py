class A:
    
    def __init__(self,a):
        self.a=a
        
    def f(self,x):
        
        return 2*x